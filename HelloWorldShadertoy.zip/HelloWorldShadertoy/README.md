Adaptation of the https://www.shadertoy.com/view/4sj3Rh#
